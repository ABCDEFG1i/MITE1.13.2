package net.minecraft.world.gen;

public interface IContext {
   int random(int p_202696_1_);

   NoiseGeneratorImproved getNoiseGenerator();
}
