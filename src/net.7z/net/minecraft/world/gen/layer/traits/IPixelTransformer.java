package net.minecraft.world.gen.layer.traits;

public interface IPixelTransformer {
   int apply(int p_apply_1_, int p_apply_2_);
}
