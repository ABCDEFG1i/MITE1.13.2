package net.minecraft.world.gen;

public class NetherGenSettings extends ChunkGenSettings {
}
