package net.minecraft.world.gen.feature.structure;

import net.minecraft.world.gen.feature.IFeatureConfig;

public class ShipwreckConfig implements IFeatureConfig {
   public final boolean field_204753_a;

   public ShipwreckConfig(boolean p_i48900_1_) {
      this.field_204753_a = p_i48900_1_;
   }
}
