package net.minecraft.world.gen.feature.structure;

import net.minecraft.world.gen.feature.IFeatureConfig;

public class OceanMonumentConfig implements IFeatureConfig {
}
