package net.minecraft.world.gen.feature;

public interface IFeatureConfig {
   NoFeatureConfig NO_FEATURE_CONFIG = new NoFeatureConfig();
}
