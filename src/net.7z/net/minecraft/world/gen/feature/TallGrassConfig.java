package net.minecraft.world.gen.feature;

import net.minecraft.block.state.IBlockState;

public class TallGrassConfig implements IFeatureConfig {
   public final IBlockState state;

   public TallGrassConfig(IBlockState p_i48667_1_) {
      this.state = p_i48667_1_;
   }
}
