package net.minecraft.world.gen.feature;

import net.minecraft.block.state.IBlockState;

public class IcebergConfig implements IFeatureConfig {
   public final IBlockState state;

   public IcebergConfig(IBlockState p_i48928_1_) {
      this.state = p_i48928_1_;
   }
}
