package net.minecraft.world.gen.feature;

public class EndGatewayConfig implements IFeatureConfig {
   private final boolean field_209960_a;

   public EndGatewayConfig(boolean p_i49500_1_) {
      this.field_209960_a = p_i49500_1_;
   }

   public boolean func_209959_a() {
      return this.field_209960_a;
   }
}
