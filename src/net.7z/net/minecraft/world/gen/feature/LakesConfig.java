package net.minecraft.world.gen.feature;

import net.minecraft.block.Block;

public class LakesConfig implements IFeatureConfig {
   public final Block field_202438_a;

   public LakesConfig(Block p_i48678_1_) {
      this.field_202438_a = p_i48678_1_;
   }
}
