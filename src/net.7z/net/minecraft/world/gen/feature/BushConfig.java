package net.minecraft.world.gen.feature;

import net.minecraft.block.Block;

public class BushConfig implements IFeatureConfig {
   public final Block block;

   public BushConfig(Block p_i48689_1_) {
      this.block = p_i48689_1_;
   }
}
