package net.minecraft.world.gen.feature;

import net.minecraft.fluid.Fluid;

public class LiquidsConfig implements IFeatureConfig {
   public final Fluid field_202459_a;

   public LiquidsConfig(Fluid p_i49002_1_) {
      this.field_202459_a = p_i49002_1_;
   }
}
