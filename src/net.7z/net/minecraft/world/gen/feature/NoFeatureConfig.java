package net.minecraft.world.gen.feature;

public class NoFeatureConfig implements IFeatureConfig {
}
