package net.minecraft.world.gen.feature;

public class HellLavaConfig implements IFeatureConfig {
   public final boolean field_202437_a;

   public HellLavaConfig(boolean p_i48680_1_) {
      this.field_202437_a = p_i48680_1_;
   }
}
