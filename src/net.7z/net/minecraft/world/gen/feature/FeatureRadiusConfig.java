package net.minecraft.world.gen.feature;

public class FeatureRadiusConfig implements IFeatureConfig {
   public final int radius;

   public FeatureRadiusConfig(int p_i48682_1_) {
      this.radius = p_i48682_1_;
   }
}
