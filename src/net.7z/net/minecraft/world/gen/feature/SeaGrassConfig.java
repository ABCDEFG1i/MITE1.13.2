package net.minecraft.world.gen.feature;

public class SeaGrassConfig implements IFeatureConfig {
   public final int field_203237_a;
   public final double field_203238_b;

   public SeaGrassConfig(int p_i48776_1_, double p_i48776_2_) {
      this.field_203237_a = p_i48776_1_;
      this.field_203238_b = p_i48776_2_;
   }
}
