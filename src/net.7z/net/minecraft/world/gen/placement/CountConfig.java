package net.minecraft.world.gen.placement;

import net.minecraft.world.gen.feature.IFeatureConfig;

public class CountConfig implements IFeatureConfig {
   public final int count;

   public CountConfig(int p_i48923_1_) {
      this.count = p_i48923_1_;
   }
}
