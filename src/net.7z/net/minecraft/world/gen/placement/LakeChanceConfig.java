package net.minecraft.world.gen.placement;

public class LakeChanceConfig implements IPlacementConfig {
   public final int rarity;

   public LakeChanceConfig(int p_i48660_1_) {
      this.rarity = p_i48660_1_;
   }
}
