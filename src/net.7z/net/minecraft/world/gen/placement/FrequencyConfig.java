package net.minecraft.world.gen.placement;

public class FrequencyConfig implements IPlacementConfig {
   public final int frequency;

   public FrequencyConfig(int p_i48664_1_) {
      this.frequency = p_i48664_1_;
   }
}
