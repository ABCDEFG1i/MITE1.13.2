package net.minecraft.world.gen.placement;

public class DungeonRoomConfig implements IPlacementConfig {
   public final int count;

   public DungeonRoomConfig(int p_i48659_1_) {
      this.count = p_i48659_1_;
   }
}
