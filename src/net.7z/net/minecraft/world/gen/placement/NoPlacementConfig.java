package net.minecraft.world.gen.placement;

public class NoPlacementConfig implements IPlacementConfig {
}
