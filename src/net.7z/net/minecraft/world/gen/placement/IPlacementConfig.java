package net.minecraft.world.gen.placement;

public interface IPlacementConfig {
   NoPlacementConfig NO_PLACEMENT_CONFIG = new NoPlacementConfig();
}
