package net.minecraft.world.gen.placement;

public class ChanceConfig implements IPlacementConfig {
   public final int chance;

   public ChanceConfig(int p_i48665_1_) {
      this.chance = p_i48665_1_;
   }
}
