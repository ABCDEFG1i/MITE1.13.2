package net.minecraft.world.gen.area;

public interface IArea {
   int getValue(int p_202678_1_, int p_202678_2_);
}
