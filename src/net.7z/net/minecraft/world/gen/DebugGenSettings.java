package net.minecraft.world.gen;

public class DebugGenSettings extends ChunkGenSettings {
}
